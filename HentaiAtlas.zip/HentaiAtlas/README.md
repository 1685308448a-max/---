# HentaiAtlas：第二张方块图集

另做一张和原版 Blocks 图集**布局相同**（16×16 格，格号 0~255）的新图，
方块填格子编号即可使用，不碰原版图集，也不用改任何 UV 计算。

> ⚠ 未编译验证。类名、方法名按《生存战争》原版源码印象编写，
> 用 dnSpy 打开 `Survivalcraft.dll` / `Engine.dll` 后对照修正（代码里标了【对照点】）。

## 目录
- `src/ExtraAtlas.cs`：加载图集、登记方块、格号→UV
- `src/ExtraAtlasDraw.cs`：物品栏/手持/掉落物的贴图切换
- `src/ExtraTerrain.cs`：世界里方块的额外几何体（每区块一份）及生命周期
- `src/HentaiAtlasEntry.cs`：入口 `Init()`
- `tools/make_template.py`、`HentaiAtlas_template.png`：带格号的空白模板
- `libs/`：把 APK 里 `assemblies/Engine.dll`、`assemblies/Survivalcraft.dll` 复制进来再编译

## 使用步骤
1. 画图：用模板画 256×256（或每格 32px 的 512×512），去掉格线，存为 `HentaiAtlas.png`，放到 `data:/` 目录。
2. 启动钩子里调用 `HentaiAtlasEntry.Init()`，并 `ExtraAtlas.RegisterBlock(你的方块Index)`。
3. 方块的 `DefaultTextureSlot` / `GetFaceTextureSlot` 照常填 0~255，指向新图的格子。
4. 在 dnSpy 里给 `Survivalcraft.dll` 打下面的补丁点。

## 补丁点（dnSpy 里改）

### 物品栏 / 手持 / 掉落物（只需包一层贴图）
把传给批处理的方块贴图包一层：
```csharp
// 原
primitivesRenderer.TexturedBatch(texture, ...);
// 改
primitivesRenderer.TexturedBatch(HentaiAtlas.ExtraAtlasDraw.PickTexture(value, texture), ...);
```
常见位置：`BlocksManager.DrawMeshBlock`、`DrawCubeBlock`、`DrawFlatBlock`、各 `Block.DrawBlock`、物品图标绘制。

### 世界里的方块（共 4 个点 + 1 次额外绘制）
| 点 | 位置 | 加什么 |
|---|---|---|
| A | 调 `GenerateTerrainVertices` 处 | `geometry` 参数换成 `ExtraTerrain.PickGeometry(chunk, value, 原geometry)` |
| B | 区块重新生成顶点开始处 | `ExtraTerrain.OnChunkRegenerateBegin(chunk)` |
| C | 主线程上传区块缓冲处 | `ExtraTerrain.UploadIfDirty(chunk)` |
| D | 区块释放缓冲/卸载处 | `ExtraTerrain.OnChunkDispose(chunk)` |

**额外绘制**：在 `TerrainRenderer` 里，原版把所有区块画完之后，
照抄原版绘制那段代码再跑一遍，只改三处：
- 贴图：`BlocksTexture` → `ExtraAtlas.Texture`（`ExtraAtlas.Texture == null` 时跳过整段）；
- 缓冲：区块的顶点/索引缓冲 → `ExtraTerrain.TryGet(chunk)` 返回的 `VertexBuffer` / `IndexBuffer`（为 null 或 `HasContent == false` 则跳过）；
- 范围：`SubsetStarts[i]` ~ `SubsetEnds[i]`，i = 0 不透明、1 镂空、2 半透明，顺序和原版一致（半透明最后画）。

采样器照原版用点采样（不要线性过滤），像素才不会糊。

## 注意
- 一个区块里使用第二图集的顶点总数不能超过 65535（ushort 索引），超出会跳过并写警告。
- 图集 PNG 尺寸用 2 的幂。
- 想看加载是否成功：查看 `data:/hentai_atlas.log`。
- 改完 dll 后如何放回、签名、安装，按你自己的流程，本项目不含打包。
