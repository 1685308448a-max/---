# -*- coding: utf-8 -*-
"""
生成第二图集的空白模板：16×16 格，每格 size 像素，带格线和格子编号。
用法：python make_template.py [每格像素，默认16]
输出：HentaiAtlas_template.png（画完后改名 HentaiAtlas.png 放到 data:/ 目录）
注意：画贴图时请把格线和编号图层隐藏/删除，最终图里不要保留。
"""
import sys
from PIL import Image, ImageDraw

size = int(sys.argv[1]) if len(sys.argv) > 1 else 16
cols = rows = 16
img = Image.new("RGBA", (cols * size, rows * size), (0, 0, 0, 0))
d = ImageDraw.Draw(img)
for i in range(cols * rows):
    x, y = (i % cols) * size, (i // cols) * size
    d.rectangle([x, y, x + size - 1, y + size - 1], outline=(255, 0, 255, 120))
    d.text((x + 2, y + 2), str(i), fill=(255, 255, 255, 160))
img.save("HentaiAtlas_template.png")
print("已生成 HentaiAtlas_template.png，尺寸", img.size)
