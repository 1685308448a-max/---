using Engine.Graphics;
using Game;

namespace HentaiAtlas
{
    /// <summary>
    /// 物品栏 / 手持 / 掉落物 / 方块图标的贴图选择。
    /// 这些路径最终都是“传一张贴图给批处理”，只要把传入的贴图
    /// 用 PickTexture 包一层，就能自动在原版图集和第二图集之间切换。
    /// </summary>
    public static class ExtraAtlasDraw
    {
        /// <summary>
        /// 选择绘制用的贴图。
        /// value：方块 value（含数据位）；original：原本要传的原版贴图。
        /// 示例（接入点，见 README）：
        ///   原：primitivesRenderer.TexturedBatch(texture, ...)
        ///   改：primitivesRenderer.TexturedBatch(ExtraAtlasDraw.PickTexture(value, texture), ...)
        /// </summary>
        public static Texture2D PickTexture(int value, Texture2D original)
        {
            return ExtraAtlas.IsExtraValue(value) ? ExtraAtlas.Texture : original;
        }
    }
}
