using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Engine;
using Engine.Graphics;
using Game;

namespace HentaiAtlas
{
    /// <summary>
    /// 每个区块（TerrainChunk）里“使用第二图集的方块”的顶点数据。
    /// 原版地形一个区块只能用一张贴图，所以这类方块的顶点不写进原版几何体，
    /// 而是写进这里，渲染时用第二图集再画一遍。
    /// 子集编号：0 = 不透明，1 = 镂空(AlphaTest)，2 = 半透明
    /// 注意：TerrainChunkGeometry / TerrainGeometrySubset / TerrainVertex 等类型
    /// 按原版源码印象编写，请对照实际 dll 修正。
    /// </summary>
    public class ExtraChunkData
    {
        public const int SubsetCount = 3;

        /// <summary>
        /// 额外几何体（直接复用游戏自己的类型，这样 Block.GenerateTerrainVertices
        /// 可以不改一行代码地往里写）。【对照点】
        /// </summary>
        public TerrainChunkGeometry Geometry = new TerrainChunkGeometry();

        /// <summary>GPU 顶点缓冲（主线程创建）</summary>
        public VertexBuffer VertexBuffer;

        /// <summary>GPU 索引缓冲（主线程创建）</summary>
        public IndexBuffer IndexBuffer;

        /// <summary>每个子集在索引缓冲里的起止位置，绘制时用</summary>
        public readonly int[] SubsetStarts = new int[SubsetCount];
        public readonly int[] SubsetEnds = new int[SubsetCount];

        /// <summary>几何体有改动、需要重新上传 GPU</summary>
        public bool Dirty;

        /// <summary>是否有内容可画</summary>
        public bool HasContent;

        /// <summary>清空几何体（区块重新生成顶点前调用）</summary>
        public void ClearGeometry()
        {
            foreach (TerrainGeometrySubset subset in GetSubsets())
            {
                subset.Vertices.Clear();
                subset.Indices.Clear();
            }
            Dirty = true;
        }

        /// <summary>按 0/1/2 顺序返回三个子集</summary>
        public TerrainGeometrySubset[] GetSubsets()
        {
            return new[]
            {
                Geometry.SubsetOpaque,
                Geometry.SubsetAlphaTest,
                Geometry.SubsetTransparent
            };
        }

        /// <summary>
        /// 把三个子集合并上传到 GPU。必须在主线程（有 GL 上下文）调用。
        /// </summary>
        public void Upload()
        {
            Dispose();
            TerrainGeometrySubset[] subsets = GetSubsets();

            int totalVertices = 0, totalIndices = 0;
            foreach (var s in subsets)
            {
                totalVertices += s.Vertices.Count;
                totalIndices += s.Indices.Count;
            }

            HasContent = totalIndices > 0;
            Dirty = false;
            if (!HasContent) return;

            // ushort 索引最多寻址 65535 个顶点，超出说明区块里这类方块太多
            if (totalVertices > ushort.MaxValue)
            {
                Log.Warning("HentaiAtlas: 区块顶点数超过 65535，已跳过上传");
                HasContent = false;
                return;
            }

            TerrainVertex[] vertices = new TerrainVertex[totalVertices];
            ushort[] indices = new ushort[totalIndices];
            int vOffset = 0, iOffset = 0;

            for (int i = 0; i < SubsetCount; i++)
            {
                TerrainGeometrySubset s = subsets[i];
                SubsetStarts[i] = iOffset;

                // 顶点原样拷贝
                for (int v = 0; v < s.Vertices.Count; v++)
                    vertices[vOffset + v] = s.Vertices.Array[v];

                // 索引要加上本子集顶点起点的偏移
                for (int k = 0; k < s.Indices.Count; k++)
                    indices[iOffset + k] = (ushort)(s.Indices.Array[k] + vOffset);

                vOffset += s.Vertices.Count;
                iOffset += s.Indices.Count;
                SubsetEnds[i] = iOffset;
            }

            VertexBuffer = new VertexBuffer(TerrainVertex.VertexDeclaration, totalVertices);
            VertexBuffer.SetData(vertices, 0, totalVertices);
            IndexBuffer = new IndexBuffer(IndexFormat.SixteenBits, totalIndices);
            IndexBuffer.SetData(indices, 0, totalIndices);
        }

        /// <summary>释放 GPU 资源</summary>
        public void Dispose()
        {
            VertexBuffer?.Dispose();
            IndexBuffer?.Dispose();
            VertexBuffer = null;
            IndexBuffer = null;
        }
    }

    /// <summary>
    /// 区块 → 额外几何体 的对应表。
    /// 用 ConditionalWeakTable，区块被回收时数据自动跟着回收，不需要改 TerrainChunk 类。
    /// </summary>
    public static class ExtraTerrain
    {
        private static readonly ConditionalWeakTable<TerrainChunk, ExtraChunkData> m_table
            = new ConditionalWeakTable<TerrainChunk, ExtraChunkData>();

        /// <summary>取得（没有则创建）某区块的额外几何体</summary>
        public static ExtraChunkData Get(TerrainChunk chunk)
        {
            return m_table.GetValue(chunk, c => new ExtraChunkData());
        }

        /// <summary>仅查询，不创建；没有则返回 null</summary>
        public static ExtraChunkData TryGet(TerrainChunk chunk)
        {
            ExtraChunkData data;
            return m_table.TryGetValue(chunk, out data) ? data : null;
        }

        /// <summary>
        /// 【接入点 A：生成顶点】
        /// 在原版调用 block.GenerateTerrainVertices(generator, geometry, value, x, y, z) 的地方，
        /// 把 geometry 参数换成本方法的返回值即可：
        ///   原：block.GenerateTerrainVertices(g, chunk.Geometry, value, x, y, z);
        ///   改：block.GenerateTerrainVertices(g,
        ///           ExtraTerrain.PickGeometry(chunk, value, chunk.Geometry), value, x, y, z);
        /// </summary>
        public static TerrainChunkGeometry PickGeometry(
            TerrainChunk chunk, int value, TerrainChunkGeometry original)
        {
            if (!ExtraAtlas.IsExtraValue(value)) return original;
            return Get(chunk).Geometry;
        }

        /// <summary>
        /// 【接入点 B：区块重新生成顶点之前】先清空旧的额外几何体，否则会越积越多。
        /// </summary>
        public static void OnChunkRegenerateBegin(TerrainChunk chunk)
        {
            ExtraChunkData data = TryGet(chunk);
            if (data != null) data.ClearGeometry();
        }

        /// <summary>
        /// 【接入点 C：主线程，每帧或区块更新后】把需要的区块上传到 GPU。
        /// </summary>
        public static void UploadIfDirty(TerrainChunk chunk)
        {
            ExtraChunkData data = TryGet(chunk);
            if (data != null && data.Dirty) data.Upload();
        }

        /// <summary>
        /// 【接入点 D：区块卸载】释放 GPU 缓冲，避免显存泄漏。
        /// </summary>
        public static void OnChunkDispose(TerrainChunk chunk)
        {
            ExtraChunkData data = TryGet(chunk);
            if (data != null) data.Dispose();
        }
    }
}
