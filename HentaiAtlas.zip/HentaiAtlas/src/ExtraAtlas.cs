using System;
using System.Collections.Generic;
using System.IO;
using Engine;
using Engine.Graphics;
using Game;

namespace HentaiAtlas
{
    /// <summary>
    /// 第二张方块图集（用法和原版 Blocks 图集一致）。
    /// - 布局：16 列 × 16 行，共 256 格，格子编号 = 行 * 16 + 列，和原版相同；
    /// - 哪些方块使用这张图，通过 RegisterBlock 登记（不需要改 Block 基类）；
    /// - 登记过的方块，DefaultTextureSlot 填 0~255 即指向本图集的格子。
    /// 注意：类名/方法名按原版源码印象编写，导入 dnSpy 后请对照实际 dll 修正。
    /// </summary>
    public static class ExtraAtlas
    {
        /// <summary>图集列数（与原版一致）</summary>
        public const int Columns = 16;

        /// <summary>图集行数（与原版一致）</summary>
        public const int Rows = 16;

        /// <summary>方块 Index 的最大数量（原版为 1024）</summary>
        private const int MaxBlocks = 1024;

        /// <summary>第二图集贴图；未加载成功时为 null，此时一切回退到原版图集</summary>
        public static Texture2D Texture { get; private set; }

        /// <summary>快速查询表：下标 = 方块 Index，值 = 是否使用第二图集</summary>
        private static readonly bool[] m_isExtra = new bool[MaxBlocks];

        /// <summary>加载日志，方便排查（写到 data:/hentai_atlas.log）</summary>
        private static void Log(string text)
        {
            try
            {
                using (Stream s = Storage.OpenFile("data:/hentai_atlas.log", OpenFileMode.CreateOrOpen))
                using (StreamWriter w = new StreamWriter(s))
                {
                    s.Seek(0, SeekOrigin.End);
                    w.WriteLine(text);
                }
            }
            catch { /* 日志失败不影响游戏 */ }
        }

        /// <summary>
        /// 从 PNG 加载第二图集。建议在游戏启动、BlocksManager 初始化之前调用一次。
        /// 默认路径：data:/HentaiAtlas.png
        /// </summary>
        public static bool Load(string path = "data:/HentaiAtlas.png")
        {
            try
            {
                if (!Storage.FileExists(path))
                {
                    Log("找不到图集文件: " + path);
                    return false;
                }
                using (Stream stream = Storage.OpenFile(path, OpenFileMode.Read))
                {
                    // 【对照点】Image.Load / Texture2D.Load 的重载以实际 Engine.dll 为准
                    Image image = Image.Load(stream);
                    // 图片尺寸最好是 2 的幂（如 256×256、512×512），否则部分安卓 GPU 显示异常
                    Texture = Texture2D.Load(image, 1);
                    Log("图集加载成功: " + image.Width + "x" + image.Height);
                }
                return true;
            }
            catch (Exception e)
            {
                Log("图集加载失败: " + e);
                Texture = null;
                return false;
            }
        }

        /// <summary>登记：这个方块 Index 使用第二图集</summary>
        public static void RegisterBlock(int blockIndex)
        {
            if (blockIndex >= 0 && blockIndex < MaxBlocks)
                m_isExtra[blockIndex] = true;
        }

        /// <summary>该方块 Index 是否使用第二图集（图集未加载成功时一律返回 false）</summary>
        public static bool IsExtraBlock(int blockIndex)
        {
            return Texture != null
                && blockIndex >= 0 && blockIndex < MaxBlocks
                && m_isExtra[blockIndex];
        }

        /// <summary>根据方块 value（含数据位）判断是否使用第二图集</summary>
        public static bool IsExtraValue(int value)
        {
            return IsExtraBlock(Terrain.ExtractContents(value));
        }

        /// <summary>
        /// 格子编号 → UV 矩形（左上角 + 右下角），归一化坐标 0~1。
        /// 和原版算法一致：每格宽 1/16。
        /// </summary>
        public static void SlotToUV(int slot, out Vector2 topLeft, out Vector2 bottomRight)
        {
            int col = slot % Columns;
            int row = slot / Columns;
            float w = 1f / Columns;
            float h = 1f / Rows;
            topLeft = new Vector2(col * w, row * h);
            bottomRight = new Vector2((col + 1) * w, (row + 1) * h);
        }
    }
}
