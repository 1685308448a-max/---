using Game;

namespace HentaiAtlas
{
    /// <summary>
    /// 入口：在游戏启动阶段调用 Init() 一次即可。
    /// 调用位置建议：HentaiEx.dll 现有的启动钩子里（日志里有 "INSTALL OK" 的那处）。
    /// </summary>
    public static class HentaiAtlasEntry
    {
        private static bool m_inited;

        public static void Init()
        {
            if (m_inited) return;
            m_inited = true;

            // 1. 加载第二图集 PNG（放在 data:/HentaiAtlas.png）
            ExtraAtlas.Load();

            // 2. 登记使用第二图集的方块。
            //    参数是方块的 Index（BlocksManager.Blocks 数组下标），
            //    例如你自己新增的方块类里的 Index 常量。
            //    示例（把 MyBlock.Index 换成你自己的）：
            //    ExtraAtlas.RegisterBlock(MyBlock.Index);
        }
    }
}
